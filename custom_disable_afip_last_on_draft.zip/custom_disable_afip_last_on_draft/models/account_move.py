# -*- coding: utf-8 -*-
from odoo import models

class AccountMove(models.Model):
    _inherit = 'account.move'

    def _skip_if_draft(self):
        return any(m.state == 'draft' for m in self)

    def _l10n_ar_edi_get_last_invoice_number(self):
        if self._skip_if_draft():
            return False
        parent_call = getattr(super(), "_l10n_ar_edi_get_last_invoice_number", None)
        if parent_call:
            return parent_call()
        return False

    def _l10n_ar_get_last_document_number(self):
        if self._skip_if_draft():
            return False
        parent_call = getattr(super(), "_l10n_ar_get_last_document_number", None)
        if parent_call:
            return parent_call()
        return False

    def _get_pyafipws_last_invoice(self):
        if self._skip_if_draft():
            return False
        parent_call = getattr(super(), "_get_pyafipws_last_invoice", None)
        if parent_call:
            return parent_call()
        return False
