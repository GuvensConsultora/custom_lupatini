# -*- coding: utf-8 -*-
{
    'name': "AR EDI: No consultar último número en borrador",
    'summary': "Evita que l10n_ar/l10n_ar_edi consulte AFIP al abrir facturas en borrador.",
    'version': "17.0.1.0.0",
    'author': "Lupatini + ChatGPT",
    'website': "https://example.com",
    'license': "LGPL-3",
    'depends': ["account", "l10n_ar", "l10n_ar_edi"],
    'data': [],
    'installable': true,
    'application': false
}
