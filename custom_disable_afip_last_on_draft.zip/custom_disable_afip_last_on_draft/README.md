# AR EDI: No consultar último número en borrador

**Propósito:** Evitar que al **abrir** una factura en *borrador* la localización argentina
consulte en AFIP el *último número autorizado* del punto de venta, para impedir errores
como **Code 11002** cuando el PV no está habilitado.

## Cómo funciona
Se hereda `account.move` y se sobreescriben las variantes más comunes del método que hace
la consulta a AFIP. Si la factura está en `state = 'draft'` devolvemos `False` y no se consulta.
Al publicar la factura, el flujo estándar queda intacto.

## Instalación
1. Copiar `custom_disable_afip_last_on_draft` a tu ruta de addons.
2. Actualizar aplicaciones e instalar el módulo.

## Compatibilidad
Odoo 17 + `l10n_ar` / `l10n_ar_edi`.
