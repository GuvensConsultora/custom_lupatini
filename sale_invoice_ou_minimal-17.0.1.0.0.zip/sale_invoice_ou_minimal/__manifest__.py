{
    "name": "Sale Invoice OU Minimal",
    "summary": "Asegura que la factura creada desde Venta tenga UO y Diario coherentes (OCA).",
    "version": "17.0.1.0.0",
    "category": "Sales/Accounting",
    "author": "Lupatini + You",
    "license": "LGPL-3",
    "depends": [
        "sale",
        "account",
        "operating_unit",
        "account_operating_unit"
    ],
    "data": [],
    "application": false,
    "installable": true
}