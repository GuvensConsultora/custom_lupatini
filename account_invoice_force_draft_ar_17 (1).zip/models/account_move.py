# -*- coding: utf-8 -*-
from odoo import api, fields, models

class AccountMove(models.Model):
    """
    Objetivo (Odoo 17):
    - Toda factura se crea en BORRADOR (state='draft').
    - No se asigna número (name) hasta confirmar (action_post).
    - Si algún flujo intenta numerar/postear antes, lo bloqueamos y lo redirigimos a action_post().
    """
    _inherit = "account.move"

    @api.model_create_multi
    def create(self, vals_list):
        """
        Interceptamos la creación para:
        1) Forzar estado 'draft' (evita que nazca 'posted').
        2) Poner name='/' como placeholder en borrador (sin numeración/AFIP).
        3) (Robustez) Apagar auto_post si viniera seteado.
        """
        for vals in vals_list:
            # 1) Siempre borrador al crear
            vals["state"] = "draft"

            # 2) Nombre en '/' mientras sea borrador
            if vals.get("name") not in (False, "/", None):
                vals["name"] = "/"
            else:
                vals["name"] = "/"

            # 3) Por si algún flujo setea auto_post, lo neutralizamos
            if "auto_post" in vals:
                vals["auto_post"] = "no"

        moves = super().create(vals_list)
        return moves

    def write(self, vals):
        """
        Interceptamos writes peligrosos:
        - Si intentan cambiar 'name' estando en borrador, lo devolvemos a '/'. Así nadie numera antes.
        - Si intentan poner state='posted' vía write(), redirigimos a action_post() (flujo correcto).
        """
        # Evitar nombre definitivo en borrador
        if "name" in vals:
            draft_moves = self.filtered(lambda m: m.state == "draft")
            if draft_moves:
                vals = dict(vals)
                vals["name"] = "/"

        # Evitar posteo directo por write(state='posted')
        if vals.get("state") == "posted":
            vals = dict(vals)
            # Quitamos el cambio de estado para escribir el resto sin saltarse reglas
            vals.pop("state")
            super(AccountMove, self).write(vals)
            # Ahora posteamos con el método oficial
            for move in self:
                if move.state == "draft":
                    move.action_post()
            return True

        return super().write(vals)

    def action_post(self):
        """
        Confirmación de factura:
        - Aquí se asigna la numeración/secuencia y, con l10n_ar, la lógica AFIP (CAE).
        - No tocamos la implementación base: dejamos que Odoo + l10n_ar hagan lo suyo.
        """
        return super().action_post()
