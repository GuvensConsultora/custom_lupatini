# AR Facturas: crear en borrador y numerar al confirmar (v17)

**Versión:** 17.0.1.0.0  
**Resumen:** Este módulo garantiza que **todas las facturas** se **creen en estado Borrador** y con `name='/'`, evitando cualquier **numeración/secuencia/AFIP** antes de **Confirmar**. La numeración fiscal (y, en Argentina, la lógica de **AFIP/CAE**) ocurre **recién** en `action_post()`.

---

## Objetivo

- Evitar que flujos personalizados, Studio o acciones de servidor **posteen** o **numeren** facturas al crearlas.
- Mantener las facturas **siempre en borrador** hasta que el usuario **confirme**.
- Asegurar que la **numeración** y validaciones **AR (l10n_ar)** se ejecuten en el punto correcto: `action_post()`.

---

## Compatibilidad

- **Odoo 17** (Community / Enterprise).
- Depende de: `account`, `l10n_ar` (para el flujo argentino).

---

## Comportamiento

1. **Creación (`create`)**
   - Fuerza `state = 'draft'`.
   - Establece `name = '/'` (placeholder de borrador).
   - Desactiva `auto_post` si viene seteado.

2. **Edición (`write`)**
   - Si la factura está en **borrador** y alguien intenta cambiar `name`, se **normaliza** a `'/'` (evita numeración temprana).
   - Si se intenta poner `state='posted'` por `write()`, se **ignora** y se llama a `action_post()` para publicar por el flujo oficial.

3. **Confirmación (`action_post`)**
   - Se delega al comportamiento nativo de Odoo/l10n_ar: **aquí** se asigna la numeración/secuencia y, de corresponder, el **CAE** (AFIP).

---

## Instalación

1. Copiar esta carpeta en el path de **addons** del servidor Odoo.
2. Actualizar Apps.
3. Instalar **“AR Facturas: crear en borrador y numerar al confirmar (v17)”**.

> No requiere configuración adicional.

---

## Uso y pruebas sugeridas

1. **Crear** factura (desde menú de Facturas, desde Pedido de Venta o desde Albarán).  
   - Resultado esperado: **Borrador**, `name = '/'`.
2. **Editar** el número manualmente en borrador y **guardar**.  
   - Resultado esperado: vuelve a **'/'**.
3. Ejecutar cualquier flujo que intente **postear** automáticamente.  
   - Resultado esperado: el módulo **redirige** a `action_post()`.
4. **Confirmar** con el botón.  
   - Resultado esperado: **Publicado** con número fiscal y (si aplica) **CAE** asignado por `l10n_ar`.

---

## Diseño técnico

- Modelo heredado: `account.move`.
- Métodos sobrescritos:
  - `create()` → fuerza borrador y `name='/'`, neutraliza `auto_post` si viene.
  - `write()` → evita numeración en borrador; traduce `state='posted'` en `action_post()`.
  - `action_post()` → sin cambios funcionales; se mantiene el flujo nativo para numeración/AFIP.
- No se añaden campos ni vistas.

---

## Buenas prácticas relacionadas

- Evitar acciones de servidor/Studio que llamen `action_post()` automáticamente si no deseás posteo inmediato.
- Si algún diario tiene automatismos, revisarlos. Este módulo igualmente **protege** el flujo estándar.

---

## Solución de problemas

- **“La factura aparece numerada al crearla”**: revisá módulos personalizados que llamen `action_post()` o escriban `name` al crear. Este módulo lo neutraliza, pero si persiste, inspeccioná `ir.logging` para ubicar el origen.
- **“Mi reporte muestra el número en borrador”**: por diseño, en borrador `name='/'`. Usá etiquetas alternativas en el reporte para el estado borrador si necesitás un identificador legible.

---

## Licencia

LGPL-3

---

## Changelog

- 2025-10-07 — Primera publicación para Odoo 17.
