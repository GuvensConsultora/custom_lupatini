# -*- coding: utf-8 -*-
{
    "name": "AR Facturas: crear en borrador y numerar al confirmar (v17)",
    "version": "17.0.1.0.0",
    "summary": "Evita asignar número/AFIP antes de confirmar; fuerza estado borrador al crear (Odoo 17)",
    "author": "Tu Empresa",
    "license": "LGPL-3",
    "depends": [
        "account",
        "l10n_ar",
    ],
    "data": [],
    "installable": True,
}
